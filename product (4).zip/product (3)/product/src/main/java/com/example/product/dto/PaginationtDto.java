package com.example.product.dto;

import lombok.Data;

@Data
public class PaginationtDto <T>{
	
	private int pageNo;
	
	private int pageSize;
	
	private long totalRecords;
	
	private T body ;
	

}
