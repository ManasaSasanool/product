package com.example.product.serviceimp;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import com.example.product.dto.PaginationtDto;
import com.example.product.dto.ProductResponseDto;
import com.example.product.entity.Product;
import com.example.product.repository.ProductRepository;
import com.example.product.service.ProductService;

@Service
public class ProductServiceImp implements ProductService {

	@Autowired
	private ProductRepository productRepository;

	@Override
	public Product addProduct(Product product) {
		Product insert = productRepository.save(product);
		return insert;
	}

	public PaginationtDto<List<ProductResponseDto>> get(int pageNo, int pageSize) {
		// Product product= new Product();
		PageRequest pageable = PageRequest.of(pageNo - 1, pageSize);
		Page<Product> pageProduct = this.productRepository.findAll(pageable);
		List<Product> p = pageProduct.getContent();
		List<ProductResponseDto> productDto = new ArrayList<ProductResponseDto>();
		for (Product pro : p) {
			ProductResponseDto dto = new ProductResponseDto();
			dto.setProduct_id(pro.getProduct_id());
			dto.setProduct_name(pro.getProduct_name());
			dto.setProduct_price(pro.getProduct_price());
			productDto.add(dto);
		}
		PaginationtDto<List<ProductResponseDto>> pagination = new PaginationtDto<>();
		pagination.setPageNo(pageProduct.getNumber());
		pagination.setPageSize(pageProduct.getSize());
		pagination.setTotalRecords(pageProduct.getTotalElements());
		pagination.setBody(productDto);
		return pagination;
	}

	@Override
	public List<Product> getAllProducts() {
		List<Product> list1 = productRepository.findAll();
		return list1;
	}
}
