package com.example.product.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.product.dto.PaginationtDto;
import com.example.product.dto.ProductResponseDto;
import com.example.product.entity.Product;
import com.example.product.service.ProductService;

@RestController
public class ProductController {
	@Autowired
	private ProductService productService;

	@PostMapping

	public ResponseEntity<Product> addProduct(@RequestBody Product product) {
		Product insert = productService.addProduct(product);
		return new ResponseEntity<Product>(insert, HttpStatus.CREATED);
	}

//	@GetMapping
//	public RessponseEntity<PaginationtDto<List<ProductResponseDto>>> get(@RequestParam("pageNo") int pageNo,
//			@RequestParam("pageSize") int pageSize){
//		return new ResponseEntity<>(this.productService.get(pageNo,pageSize),HttpStatus.OK);
//	}
	@GetMapping
	public PaginationtDto<List<ProductResponseDto>> get(@RequestParam("pageNo") int pageNo,
			@RequestParam("pageSize") int pageSize) {
		return productService.get(pageNo, pageSize);

	}

	@GetMapping("/getallproducts")
	public ResponseEntity<List<Product>> getAllProducts() {
		List<Product> list1 = productService.getAllProducts();
		return new ResponseEntity<List<Product>>(list1, HttpStatus.ACCEPTED);
	}
}
